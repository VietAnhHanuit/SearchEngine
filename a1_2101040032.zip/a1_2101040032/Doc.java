import java.util.*;
import java.util.stream.Collectors;

public class Doc {
    private  List<Word> titleee;

    private  List<Word> bodyyy;

    private  List<Word> tatcatu = new ArrayList<>();

    public Doc(String content) {
        titleee = Arrays
                .stream(content.split("\n")[0].split(" "))
                .map(Word::createWord)
                .collect(Collectors.toList());
        bodyyy = Arrays
                .stream(content.split("\n")[1].split(" "))
                .map(Word::createWord)
                .collect(Collectors.toList());
        tatcatu.addAll(titleee);
        tatcatu.addAll(bodyyy);
    }

    public List<Word> getTitle() {
        return titleee;
    }

    public List<Word> getBody() {
        return bodyyy;
    }
    public List<Word> getAllWords() {
        return tatcatu;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Doc doc = (Doc) o;
        return Objects.equals(titleee, doc.titleee) && Objects.equals(bodyyy, doc.bodyyy) && Objects.equals(tatcatu, doc.tatcatu);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titleee, bodyyy, tatcatu);
    }




}

