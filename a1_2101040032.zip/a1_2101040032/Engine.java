
import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Engine {
    private Doc[] docs = new Doc[100];



    public int loadDocs(String dirname) {
        int numberOfDocs = 0;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(dirname))) {
            for (Path file : stream) {
                try (FileReader fileReader = new FileReader(file.toFile().getAbsolutePath());
                     BufferedReader bufferedReader = new BufferedReader(fileReader)) {
                    String message = bufferedReader.readLine() + "\n" + bufferedReader.readLine();
                    Doc doc1 = new Doc(message);
                    docs[numberOfDocs] = doc1;
                    numberOfDocs++;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return numberOfDocs;
    }

    public List<Result> search(Query query) {
        List<Result> results = new ArrayList<>();
        for (Doc doc : this.docs) {
            List<Match> matches = query.matchAgainst(doc);
            if (!matches.isEmpty()) {
                results.add(new Result(doc, matches));
            }
        }
        Collections.sort(results);
        return results;
    }

    public String htmlResult(List<Result> result) {
        StringBuilder stringBuilder = new StringBuilder();
        result.stream()
                .filter(a -> a.htmlHighlight() != null)
                .forEach(a -> stringBuilder.append(a.htmlHighlight()));
        return stringBuilder.toString();
    }
}

