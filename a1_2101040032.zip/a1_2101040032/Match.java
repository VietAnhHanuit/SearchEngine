

import java.util.ArrayList;
import java.util.List;
public class Match implements Comparable<Match>{
    private final Doc doccccc;

    private final Word wordddd;

    private  int freq = 0;

    private final int firstIndex;

    private List<Integer> index;


    public Match(Doc d, Word w, int freqqq, int firstIndex) {
        this.doccccc = d;
        this.wordddd = w;
        this.freq = freqqq;
        this.firstIndex = firstIndex;
    }

    public int getFreq() {
        this.index = new ArrayList<>();
        this.freq = 0;
        List<Word> allWords = new ArrayList<>(doccccc.getTitle());
        allWords.addAll(doccccc.getBody());
        for (int i = 0; i < allWords.size(); i++) {
            if (wordddd.equals(allWords.get(i))) {
                this.index.add(i);
                this.freq++;
            }
        }

        return this.freq;
    }
    public int getFirstIndex() {
        for (int i = 0; i < doccccc.getAllWords().size(); i++) {
            if (wordddd.equals(doccccc.getAllWords().get(i))) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int compareTo(Match match) {
        return this.getFirstIndex() > match.getFirstIndex() ? 0 : -1;
    }

    public Word getWord() {
        return this.wordddd;
    }
}

