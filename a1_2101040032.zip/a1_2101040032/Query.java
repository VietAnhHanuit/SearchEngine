import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Query {
    private final List<Word> keywordsss;


    public Query(String searchPhrase) {
        keywordsss = Arrays.stream(searchPhrase.split(" "))
                .map(Word::createWord)
                .filter(this::isKeyWord)
                .collect(Collectors.toList());
    }

    boolean isKeyWord(Word word) {
        return (word.isKeyword());
    }


    public List<Word> getKeywords() {
        return keywordsss;
    }

    public List<Match> matchAgainst(Doc d) {

        List<Match> matches = new ArrayList<>();
        this.keywordsss
                .stream()
                .filter(a -> d != null && d.getAllWords().contains(a))
                .forEach(a -> {
                    int freqqqq = 0;
                    int firstIndexxxxx = 0;
                    int b = 0;
                    while (b < d.getAllWords().size()) {
                        if (d.getAllWords().get(b).equals(a)) {
                            freqqqq++;
                            firstIndexxxxx = b;
                            break;
                        }
                        b++;
                    }
                    matches.add(new Match(d, a, freqqqq, firstIndexxxxx));
                });
        matches.sort(Match::compareTo);
        return matches;

    }}

