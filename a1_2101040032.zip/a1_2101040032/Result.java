
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
public class Result  implements Comparable<Result> {

    private final List<Match> matchListtt;

    private final   Doc doccc;
    private final double averageFirstIndexxx;


    public Result(Doc dddd, List<Match> matchessss) {
        this.doccc = dddd;
        this.matchListtt = matchessss;
        this.averageFirstIndexxx = matchessss.stream().mapToInt(Match::getFirstIndex).average().orElse(0.0);
    }

    public List<Match> getMatches() {
        return this.matchListtt;
    }


    public int getTotalFrequency() {
        return getMatches().get(0).getFreq();
    }

    public double getAverageFirstIndex() {
       return this.averageFirstIndexxx;}


    public String htmlHighlight() {
        Set<Word> matchedWords = this.matchListtt.stream().map(Match::getWord).collect(Collectors.toSet());
        return "<h3>" +
                this.highlightWords(this.doccc.getTitle(), matchedWords, "<u>") +
                "</h3>" +
                "<p>" +
                this.highlightWords(this.doccc.getBody(), matchedWords, "<b>") +
                "</p>";
    }
    private String highlightWords(List<Word> words, Set<Word> matchedWords, String tag) {
        return words.stream().map(word -> {
            if (matchedWords.contains(word)) {
                return word.getPrefix() + tag + word.getText() + tag.replace("<", "</") + word.getSuffix();
            } else {
                return word.toString();
            }
        }).collect(Collectors.joining(" "));
    }


    @Override
    public int compareTo(Result o) {
        return (this.getMatches().size() > o.getMatches().size()) ? -1
                : (this.getMatches().size() < o.getMatches().size()) ? 1
                : (this.getTotalFrequency() > o.getTotalFrequency()) ? -2
                : (this.getTotalFrequency() < o.getTotalFrequency()) ? 2
                : 0;
    }

    public Doc getDoc() {
        return doccc;
    }
}
