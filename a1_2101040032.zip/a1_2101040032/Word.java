

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Word {
    public static Set<String> stopWords;
    private final String prefix, text, suffix;


    public Word(String prefix, String text, String suffix) {
        this.prefix = prefix;
        this.text = text;
        this.suffix = suffix;
    }

    public static Word createWord(String rawText) {
        StringBuilder prefix = new StringBuilder();
        StringBuilder text = new StringBuilder();
        StringBuilder suffix = new StringBuilder();
        int a,b,c;
        a = 0;
        while (a < rawText.length() && !cophaikytuhoplehong(rawText.charAt(a))) {
            prefix.append(rawText.charAt(a));
            a++;
        }
        b = a;
        while (b < rawText.length()) {
            if (cophaikytuhoplehong(rawText.charAt(b))) {
                if (rawText.charAt(b) == ',' && b > 1) {
                    break;
                } else if (rawText.charAt(b) == '.' && (rawText.charAt(b - 1) > '9' || rawText.charAt(b - 1) < '0') && (rawText.length() - b < 3)) {
                    break;
                } else {
                    text.append(rawText.charAt(b));
                }
            } else {
                break;
            }
            b++;
        }

        c = b;
        while (c < rawText.length()) {
            suffix.append(rawText.charAt(c));
            c++;
        }
        return new Word(prefix.toString(), text.toString(), suffix.toString());
    }


    public static boolean cophaikytuhoplehong(char i) {
        return (i <= 'z' && i >= 'a') || (i <= 'Z' && i >= 'A') || (i == ',') ||
                (i == '.') || (i == '-') || ('0' <= i && '9' >= i);
    }


    public static boolean loadStopWords(String fileName) {
        stopWords = new HashSet<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                stopWords.add(line.trim().toLowerCase());
            }
            return true;

        } catch (IOException e) {
            return false;
        }
    }


    public boolean isKeyword() {
        if (this.getText().isEmpty()) {
            return false;
        }

        if (stopWords.contains(this.getText().toLowerCase())) {
            return false;
        }

        for (int i = 0; i < this.getText().length(); i++) {
            if (this.getText().charAt(i) <= '9' && this.getText().charAt(i) >= '0') {
                return false;
            }
        }
        return true;
    }


    public String getPrefix() {
        return this.prefix;
    }


    public String getSuffix() {
        return this.suffix;
    }


    public String getText() {
        return this.text;
    }


    @Override
    public int hashCode() {
        return this.text.toLowerCase().hashCode();
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Word)) {
            return false;
        }
        Word word;
        word = (Word) o;
        return this.text.equalsIgnoreCase(word.text);
    }

    @Override
    public String toString() {
        return this.prefix + this.text + this.suffix;
    }
}